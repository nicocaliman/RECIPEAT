
  // Opcional: autocerrar el modal tras unos segundos
  setTimeout(() => {
    document.getElementById('flashSaludo').close();
  }, 3000);